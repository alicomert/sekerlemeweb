package Model;

public class uyeModel {

    private String uyeid;
    private String adi;
    private String soyadi;
    private String yas;
    private String eposta;
    private String il;
    private String ilce;
    private String adres;
    private String uye_durumu;
    private String sifre;

    public uyeModel(String eposta) {
        this.eposta = eposta;
    }

    //giris yap
    public uyeModel(String eposta, String sifre) {
        this.eposta = eposta;
        this.sifre = sifre;
    }

    //kayıt ol
    public uyeModel(String adi, String soyadi, String eposta, String sifre) {
        this.adi = adi;
        this.soyadi = soyadi;
        this.eposta = eposta;
        this.sifre = sifre;
    }

    
    

    public uyeModel(String uyeid, String adi, String soyadi,
            String yas, String eposta, String il, String ilce, String adres, String uye_durumu, String sifre) {
        this.uyeid = uyeid;
        this.adi = adi;
        this.soyadi = soyadi;
        this.yas = yas;
        this.eposta = eposta;
        this.il = il;
        this.ilce = ilce;
        this.adres = adres;
        this.uye_durumu = uye_durumu;
        this.uye_durumu = uye_durumu;
        this.sifre = sifre;
    }

    public String getuyeid() {
        return uyeid;
    }

    public void setuyeid(String uyeid) {
        this.uyeid = uyeid;
    }

    public String getadi() {
        return adi;
    }

    public void setadi(String adi) {
        this.adi = adi;
    }

    public String getsoyadi() {
        return soyadi;
    }

    public void setsoyadi(String soyadi) {
        this.soyadi = soyadi;
    }

    public String getyas() {
        return yas;
    }

    public void setyas(String yas) {
        this.yas = yas;
    }

    public String geteposta() {
        return eposta;
    }

    public void seteposta(String eposta) {
        this.eposta = eposta;
    }

    public String getil() {
        return il;
    }

    public void setil(String il) {
        this.il = il;
    }

    public String getilce() {
        return ilce;
    }

    public void setilce(String ilce) {
        this.ilce = ilce;
    }

    public String getadres() {
        return adres;
    }

    public void setadres(String adres) {
        this.adres = adres;
    }

    public String getuye_durumu() {
        return uye_durumu;
    }

    public void setuye_durumu(String uye_durumu) {
        this.uye_durumu = uye_durumu;
    }

    public String getSifre() {
        return sifre;
    }

    public void setSifre(String sifre) {
        this.sifre = sifre;
    }

}
