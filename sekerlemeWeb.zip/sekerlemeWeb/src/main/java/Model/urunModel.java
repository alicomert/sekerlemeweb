/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author knurh
 */
public class urunModel{
    private int urunId;
    private String urunAdi;
    private String kategoriAdi;
    private String urunResmi;
    private double fiyat;
    private int kategoriId;
    private double urunadet;
    private int aktifPasif;

    public urunModel(int urunId, double urunadet) {
        this.urunId = urunId;
        this.urunadet = urunadet;
    }

    

    
    // KategoriListeleme
    public urunModel(String kategoriAdi, int kategoriId, String urunResmi) {
        this.kategoriAdi = kategoriAdi;
        this.kategoriId = kategoriId;
        this.urunResmi = urunResmi;
    }

    //urunGuncelleme icin
    public urunModel(int urunId, String urunAdi, String urunResmi, double fiyat, int kategoriId, int aktifPasif) {
        this.urunId = urunId;
        this.urunAdi = urunAdi;
        this.urunResmi = urunResmi;
        this.fiyat = fiyat;
        this.kategoriId = kategoriId;
        this.aktifPasif = aktifPasif;
      
    }

    //Urun ekleme icin
    public urunModel(String urunAdi, String urunResmi, double fiyat, int kategoriId, double urunadet) {
        this.urunAdi = urunAdi;
        this.urunResmi = urunResmi;
        this.fiyat = fiyat;
        this.kategoriId = kategoriId;
        this.urunadet=urunadet;
    }

    

    public urunModel(int urunId) {
        this.urunId = urunId;
    }

    //urun Listeleme icin
    public urunModel(int urunId, String urunAdi, String kategoriAdi, String urunResmi, double fiyat, double urunadet, int aktifPasif) {
        this.urunId = urunId;
        this.urunAdi = urunAdi;
        this.kategoriAdi = kategoriAdi;
        this.urunResmi = urunResmi;
        this.fiyat = fiyat;
        this.urunadet=urunadet;
        this.aktifPasif=aktifPasif;
    }
    public urunModel(int urunId, String urunAdi, String kategoriAdi, String urunResmi, double fiyat, double urunadet) {
        this.urunId = urunId;
        this.urunAdi = urunAdi;
        this.kategoriAdi = kategoriAdi;
        this.urunResmi = urunResmi;
        this.fiyat = fiyat;
        this.urunadet=urunadet;
    }

    public int getUrunId() {
        return urunId;
    }

    public void setUrunId(int urunId) {
        this.urunId = urunId;
    }

    public String getUrunAdi() {
        return urunAdi;
    }

    public void setUrunAdi(String urunAdi) {
        this.urunAdi = urunAdi;
    }

    public String getKategoriAdi() {
        return kategoriAdi;
    }

    public void setKategoriAdi(String kategoriAdi) {
        this.kategoriAdi = kategoriAdi;
    }

    public String getUrunResmi() {
        return urunResmi;
    }

    public void setUrunResmi(String urunResmi) {
        this.urunResmi = urunResmi;
    }

    public double getFiyat() {
        return fiyat;
    }

    public void setFiyat(double fiyat) {
        this.fiyat = fiyat;
    }
    
    public int getKategoriId() {
        return kategoriId;
    }

    public void setKategoriId(int kategoriId) {
        this.kategoriId = kategoriId;
    }

    public double getUrunadet() {
        return urunadet;
    }

    public void setUrunadet(double urunadet) {
        this.urunadet = urunadet;
    }
    
    public int getAktifPasif() {
        return aktifPasif;
    }

    public void setAktifPasif(char aktifPasif) {
        this.aktifPasif = aktifPasif;
    }
}
