/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author knurh
 */
public class siparisModel {
    int musteriID;
    private int siparisId;
    private String musteriadi;
    private String durum;
    private int durumId;
    private String urun;
    private int urunID;
    private int urun_fiyat;
    private  double miktar;
    private String musterisoyadi;
    private String musteriAdres;
    private String musteriPosta;
    private String siparis_tarih;
    
    //Silme
    public siparisModel(int siparisId) {    
        this.siparisId = siparisId;
    }

    //ekleme
    public siparisModel(int musteriID, int durumId, int urunID, double miktar) {    
        this.musteriID = musteriID;
        this.durumId = durumId;
        this.urunID = urunID;
        this.miktar = miktar;
    }

    //urun
    public siparisModel(String urun, int urunID, int urun_fiyat) {    
        this.urun = urun;
        this.urunID = urunID;
        this.urun_fiyat = urun_fiyat;
    }

    //Durum
    public siparisModel(String durum, int durumId) {
        this.durum = durum;
        this.durumId = durumId;
    }
    
    //uye bolumu
    public siparisModel(int musteriID, String musteriadi, String musterisoyadi, String musteriAdres, String musteriPosta) {
        this.musteriID = musteriID;
        this.musteriadi = musteriadi;
        this.musterisoyadi = musterisoyadi;
        this.musteriAdres = musteriAdres;
        this.musteriPosta = musteriPosta;
    }
   
    //durum
    public siparisModel(String durum) {
        this.durum = durum;
    }
   

     //Sipariş listeleme
    public siparisModel(int siparisId, String musteriadi, String durum, String urun, double miktar, String musterisoyadi, String musteriAdres, String musteriPosta,String siparis_tarih) {
        this.siparisId = siparisId;
        this.musteriadi = musteriadi;
        this.durum = durum;
        this.urun = urun;
        this.miktar = miktar;
        this.musterisoyadi = musterisoyadi;
        this.musteriAdres = musteriAdres;
        this.musteriPosta = musteriPosta;
        this.siparis_tarih=siparis_tarih;
    }
    
    public String getMusterisoyadi() {
        return musterisoyadi;
    }

    public void setMusterisoyadi(String musterisoyadi) {
        this.musterisoyadi = musterisoyadi;
    }

    public String getMusteriAdres() {
        return musteriAdres;
    }

    public void setMusteriAdres(String musteriAdres) {
        this.musteriAdres = musteriAdres;
    }

    public String getMusteriPosta() {
        return musteriPosta;
    }

    public void setMusteriPosta(String musteriPosta) {
        this.musteriPosta = musteriPosta;
    }

   

    public int getSiparisId() {
        return siparisId;
    }

    public void setSiparisId(int siparisId) {
        this.siparisId = siparisId;
    }

    public String getMusteriadi() {
        return musteriadi;
    }

    public void setMusteriadi(String musteriadi) {
        this.musteriadi = musteriadi;
    }

    public String getDurum() {
        return durum;
    }

    public void setDurum(String durum) {
        this.durum = durum;
    }

    public String getUrun() {
        return urun;
    }

    public void setUrun(String urun) {
        this.urun = urun;
    }

    public double getMiktar() {
        return miktar;
    }

    public void setMiktar(double miktar) {
        this.miktar = miktar;
    }

    public String getSiparis_tarih() {
        return siparis_tarih;
    }

    public void setSiparis_tarih(String siparis_tarih) {
        this.siparis_tarih = siparis_tarih;
    }

    public int getMusteriID() {
        return musteriID;
    }

    public void setMusteriID(int musteriID) {
        this.musteriID = musteriID;
    }

    public int getDurumId() {
        return durumId;
    }

    public void setDurumId(int durumId) {
        this.durumId = durumId;
    }

    public int getUrunID() {
        return urunID;
    }

    public void setUrunID(int urunID) {
        this.urunID = urunID;
    }

    public int getUrun_fiyat() {
        return urun_fiyat;
    }

    public void setUrun_fiyat(int urun_fiyat) {
        this.urun_fiyat = urun_fiyat;
    }
    
}
