package Control;

import java.util.*;
import java.sql.*;
import Model.uyeModel;

public class uyeControl extends dbControl {

    dbControl db = new dbControl();
    Connection conn = db.baglan();

    public boolean uyeKontrol(uyeModel uye) {
        boolean sonuc = false;
        try {
            sql = "SELECT * FROM uyetakip";
            preparedStatement = conn.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                if (uye.geteposta().equals(resultSet.getString("eposta")) && uye.getSifre().equals(resultSet.getString("sifre"))) {
                    sonuc = true;
                }
            }
            return sonuc;
        } catch (Exception e) {
            return sonuc;
        }
    }
    
    public boolean uyeEpostaKontrol(uyeModel uye) {
        boolean sonuc = false;
        try {
            sql = "SELECT * FROM uyetakip";
            preparedStatement = conn.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                if (uye.geteposta().equals(resultSet.getString("eposta"))) {
                    sonuc = true;
                }
            }
            return sonuc;
        } catch (Exception e) {
            return sonuc;
        }
    }

    public List<uyeModel> uyeGetir() {
        List<uyeModel> liste = new ArrayList();
        try {
            sql = "SELECT * FROM uyetakip";
            preparedStatement = conn.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                uyeModel uye = new uyeModel(resultSet.getString("uyeid"), resultSet.getString("adi"),
                        resultSet.getString("soyadi"), resultSet.getString("yas"), resultSet.getString("eposta"), resultSet.getString("il"), resultSet.getString("ilce"), resultSet.getString("adres"), resultSet.getString("uye_durumu"), resultSet.getString("sifre"));

                liste.add(uye);
            }
            return liste;
        } catch (Exception e) {
            return null;
        }
    }

    public void uyeEkle(uyeModel uye) {
        try {
            sql = "INSERT INTO uyeTakip(uyeid,adi,soyadi,yas,eposta,il,ilce,adres,uye_durumu,sifre) VALUES(?,?,?,?,?,?,?,?,?,?)";
            preparedStatement = conn.prepareStatement(sql);

            preparedStatement.setString(1, uye.getuyeid());
            preparedStatement.setString(2, uye.getadi());
            preparedStatement.setString(3, uye.getsoyadi());
            preparedStatement.setString(4, uye.getyas());
            preparedStatement.setString(5, uye.geteposta());
            preparedStatement.setString(6, uye.getil());
            preparedStatement.setString(7, uye.getilce());
            preparedStatement.setString(8, uye.getadres());
            preparedStatement.setString(9, uye.getuye_durumu());
            preparedStatement.setString(10, uye.getSifre());

            preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void uyeGuncelle(uyeModel uye) {
        try {
            sql = "UPDATE uyetakip SET adi=?,soyadi=?,yas=?,eposta=?,il=?,ilce=?,adres=?,uye_durumu=? sifre=? WHERE uyeid=?";
            preparedStatement = conn.prepareStatement(sql);

            preparedStatement.setString(1, uye.getadi());
            preparedStatement.setString(2, uye.getsoyadi());
            preparedStatement.setString(3, uye.getyas());
            preparedStatement.setString(4, uye.geteposta());
            preparedStatement.setString(5, uye.getil());
            preparedStatement.setString(6, uye.getilce());
            preparedStatement.setString(7, uye.getadres());
            preparedStatement.setString(8, uye.getuye_durumu());
            preparedStatement.setString(8, uye.getSifre());
            preparedStatement.setString(9, uye.getuyeid());
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void uyeSil(uyeModel uye) {
        try {
            sql = "DELETE FROM uyeTakip WHERE uyeid=?";
            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, uye.getuyeid());
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
      public void uyeKayit (uyeModel uye) {
          
        try {
            sql = "INSERT INTO uyeTakip(uyeid,adi,soyadi,eposta,sifre) VALUES(?,?,?,?,?)";
            preparedStatement = conn.prepareStatement(sql);

            preparedStatement.setString(1, uye.getuyeid());
            preparedStatement.setString(2, uye.getadi());
            preparedStatement.setString(3, uye.getsoyadi());
            preparedStatement.setString(4, uye.geteposta());
            preparedStatement.setString(5, uye.getSifre());

            preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
