/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import java.util.*;
import java.sql.*;
import Model.adminModel;
/**
 *
 * @author knurh
 */
public class adminControl extends dbControl{
    dbControl db = new dbControl();
    Connection connection = db.baglan();
    public boolean yoneticiKontrol(adminModel model){
        boolean sonuc =false;
        try {
            sql = "SELECT * FROM yoneticiler";
            preparedStatement = connection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {                
                if(model.getKullaniciAdi().equals(resultSet.getString("kullaniciAdi")) && model.getSifre().equals(resultSet.getString("sifre"))) sonuc=true;
            }
            return sonuc;
        } catch (Exception e) {
            return sonuc;
        }
    }
}
