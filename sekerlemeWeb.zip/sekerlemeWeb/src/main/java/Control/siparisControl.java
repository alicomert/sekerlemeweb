package Control;

import java.util.List;
import Model.siparisModel;
import java.sql.Connection;
import java.util.*;

public class siparisControl extends dbControl {

    dbControl db = new dbControl();
    Connection conn = db.baglan();

    public boolean siparisKontrol(siparisModel siparis) {
        boolean sonuc = false;
        try {
            sql = "Select * From siparisler";
            preparedStatement = conn.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                if (siparis.getSiparisId() == resultSet.getInt("siparis_id")) {
                    return true;
                }
            }
            return sonuc;
        } catch (Exception e) {
            return sonuc;
        }
    }

    public List<siparisModel> siparisGetir() {
        List<siparisModel> list = new ArrayList();
        try {
            sql = "SELECT * FROM siparisler, urunler, siparisdurum, uyetakip where siparisler.musteriID=uyetakip.uyeid AND siparisler.durumID=siparisdurum.durum_id AND siparisler.urun_id=urunler.urun_id";
            preparedStatement = conn.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                siparisModel siparis = new siparisModel(resultSet.getInt("Siparis_id"), resultSet.getString("adi"), resultSet.getString("durum_bilgi"), resultSet.getString("urun_adi"), resultSet.getDouble("miktar"), resultSet.getString("soyadi"), resultSet.getString("adres"), resultSet.getString("eposta"), resultSet.getString("siparis_tarih"));
                list.add(siparis);
            }
            return list;
        } catch (Exception e) {
            return null;
        }
    }

    public void siparisEkle(siparisModel siparis) {
        try {
            sql = "INSERT INTO siparisler (Siparis_id, musteriID, durumID, urun_id, miktar) VALUES(?,?,?,?,?)";
            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1, siparis.getSiparisId());
            preparedStatement.setInt(2, siparis.getMusteriID());
            preparedStatement.setInt(3, siparis.getDurumId());
            preparedStatement.setInt(4, siparis.getUrunID());
            preparedStatement.setDouble(5, siparis.getMiktar());

            preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void siparisSil(siparisModel siparis) {
        try {
            sql = "DELETE FROM siparisler WHERE Siparis_id=?";
            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1, siparis.getSiparisId());
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
    public List<siparisModel> durumGetir() {
        List<siparisModel> list = new ArrayList();
        try {
            sql = "SELECT * FROM siparisdurum";
            preparedStatement = conn.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                siparisModel siparis = new siparisModel(resultSet.getString("durum_bilgi"), resultSet.getInt("durum_id"));
                list.add(siparis);
            }
            return list;
        } catch (Exception e) {
            return null;
        }
    }
}
