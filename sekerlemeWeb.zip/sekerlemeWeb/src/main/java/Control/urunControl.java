package Control;

import java.sql.*;
import Model.urunModel;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author knurh
 */
public class urunControl extends dbControl {

    dbControl db = new dbControl();
    Connection conn = db.baglan();

    public boolean urunKontrol(urunModel urun) {
        boolean sonuc = false;
        try {
            sql = "Select * From urunler";
            preparedStatement = conn.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                if (urun.getUrunId() == resultSet.getInt("urunId")) {
                    return true;
                }
            }
            return sonuc;
        } catch (Exception e) {
            return sonuc;
        }
    }

    public List<urunModel> urunGetir() {
        List<urunModel> list = new ArrayList();
        try {
            sql = "SELECT * FROM urunler, kategoriler "
                    + "WHERE urunler.kategori_id=kategoriler.kategori_id Order By urun_id ASC";
            preparedStatement = conn.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                urunModel urun = new urunModel(
                        resultSet.getInt("urun_id"), resultSet.getString("urun_adi"),
                        resultSet.getString("kategori_adi"), resultSet.getString("urun_resmi"), resultSet.getInt("urun_fiyat"),
                        resultSet.getDouble("urun_adet"), resultSet.getInt("aktifPasif"));
                list.add(urun);
            }
            return list;
        } catch (Exception e) {
            return null;
        }
    }

    public List<urunModel> kategoriGetir() {
        List<urunModel> list = new ArrayList();
        try {
            sql = "Select * From kategoriler";
            preparedStatement = conn.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                urunModel kategori = new urunModel(resultSet.getString("kategori_adi"), resultSet.getInt("kategori_id"), resultSet.getString("resim"));
                list.add(kategori);
            }
            return list;

        } catch (Exception e) {
            return null;
        }
    }

    public List<urunModel> urunKritikStokGetir() {
        List<urunModel> list = new ArrayList();
        try {
            sql = "SELECT urun_id, urun_adi, kategori_adi, urun_resmi, urun_fiyat,urun_adet FROM urunler, kategoriler WHERE urun_adet<20 AND urunler.kategori_id=kategoriler.kategori_id Order By urun_id ASC ";
            preparedStatement = conn.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                urunModel urun = new urunModel(resultSet.getInt("urun_id"), resultSet.getString("urun_adi"), resultSet.getString("kategori_adi"), resultSet.getString("urun_resmi"), resultSet.getInt("urun_fiyat"), resultSet.getDouble("urun_adet"));
                list.add(urun);
            }
            return list;
        } catch (Exception e) {
            return null;
        }
    }

    public void urunEkle(urunModel urun) {
        try {
            sql = "INSERT INTO urunler(urun_adi, kategori_id, urun_resmi, urun_fiyat, urun_adet) VALUES(?,?,?,?,?)";
            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, urun.getUrunAdi());
            preparedStatement.setInt(2, urun.getKategoriId());
            preparedStatement.setString(3, urun.getUrunResmi());
            preparedStatement.setDouble(4, urun.getFiyat());
            preparedStatement.setDouble(5, urun.getUrunadet());
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void urunDuzenle(urunModel urun) {
        try {
            sql = "UPDATE urunler SET urun_adi=?, kategori_id=?, urun_resmi=?, urun_fiyat=?, aktifPasif=? WHERE urun_id=? ";
            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, urun.getUrunAdi());
            preparedStatement.setInt(2, urun.getKategoriId());
            preparedStatement.setString(3, urun.getUrunResmi());
            preparedStatement.setDouble(4, urun.getFiyat());
            preparedStatement.setInt(5, urun.getAktifPasif());
            preparedStatement.setInt(6, urun.getUrunId());
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void stokEkle(urunModel urun) {
        try {
            sql = "UPDATE urunler SET urun_adet=? WHERE urun_id=? ";
            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setDouble(1, urun.getUrunadet());
            preparedStatement.setInt(2, urun.getUrunId());
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void urunSil(urunModel urun) {
        try {
            sql = "DELETE FROM urunler WHERE urun_id=?";
            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1, urun.getUrunId());
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
