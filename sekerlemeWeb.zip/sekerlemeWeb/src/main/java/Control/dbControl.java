/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;
import java.sql.*;
/**
 *
 * @author knurh
 */
public class dbControl {
    public PreparedStatement preparedStatement = null;
    public ResultSet resultSet=null;
    public String sql = null;
    public Connection baglan(){
        Connection sekerleme=null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            sekerleme=DriverManager.getConnection("jdbc:mysql://localhost:3306/sekerleme","root","123456789");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return sekerleme;
    }
}
